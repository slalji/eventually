
-- --------------------------------------------------------

--
-- Table structure for table `ussd_session`
--

DROP TABLE IF EXISTS `ussd_session`;
CREATE TABLE IF NOT EXISTS `ussd_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fulltimestamp` datetime DEFAULT NULL,
  `msisdn` varchar(12) DEFAULT NULL,
  `sessionid` varchar(25) DEFAULT NULL,
  `service` varchar(10) DEFAULT NULL,
  `servicekey` varchar(3) DEFAULT NULL,
  `ussdbody` varchar(10) DEFAULT NULL,
  `messagestring` varchar(200) DEFAULT NULL,
  `state` varchar(10) DEFAULT 'ACTIVE',
  `reference` varchar(25) DEFAULT NULL,
  `serviceoption` varchar(2) DEFAULT '0',
  `command` varchar(10) DEFAULT NULL,
  `memory` varchar(1) DEFAULT '0',
  `language` varchar(2) DEFAULT 'U',
  `sequence` varchar(10) DEFAULT '1',
  `back` varchar(5) DEFAULT '1',
  `auth` varchar(1) DEFAULT '0',
  `temp` varchar(100) DEFAULT '-',
  `choice` varchar(50) DEFAULT 'U',
  `parent` int(10) DEFAULT '-1',
  `parenttype` varchar(1) DEFAULT 'U',
  PRIMARY KEY (`id`),
  KEY `msisdn` (`msisdn`),
  KEY `reference` (`reference`),
  KEY `sessionid` (`sessionid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
