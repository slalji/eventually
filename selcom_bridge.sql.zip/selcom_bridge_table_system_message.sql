
-- --------------------------------------------------------

--
-- Table structure for table `system_message`
--

DROP TABLE IF EXISTS `system_message`;
CREATE TABLE IF NOT EXISTS `system_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `en` varchar(160) COLLATE latin1_general_ci NOT NULL,
  `sw` varchar(160) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `system_message`
--

INSERT INTO `system_message` (`id`, `code`, `en`, `sw`) VALUES
(1, 400, 'Validation Error', 'Validation Error');
