
-- --------------------------------------------------------

--
-- Table structure for table `system_accounts`
--

DROP TABLE IF EXISTS `system_accounts`;
CREATE TABLE IF NOT EXISTS `system_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `account_number` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subscript` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pin` int(11) NOT NULL,
  `tstatus` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'NEW',
  `creator` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'DEFAULT',
  `modifier` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'DEFAULT',
  `authorizer` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'DEFAULT',
  `astatus` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'PENDING',
  `rtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
