
-- --------------------------------------------------------

--
-- Table structure for table `cbsg_init_menu`
--

DROP TABLE IF EXISTS `cbsg_init_menu`;
CREATE TABLE IF NOT EXISTS `cbsg_init_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `body_en` varchar(500) NOT NULL,
  `body_sw` varchar(200) NOT NULL,
  `type` int(2) DEFAULT '1',
  `child_type` varchar(1) NOT NULL DEFAULT 'M',
  `parent` int(10) NOT NULL DEFAULT '0',
  `multiaccountflag` varchar(1) NOT NULL DEFAULT '-',
  `menuheader` int(11) NOT NULL DEFAULT '0',
  `hide` int(1) NOT NULL DEFAULT '0',
  `user_level` int(2) NOT NULL,
  `constrain` varchar(50) NOT NULL DEFAULT 'NONE',
  `cparams` varchar(50) NOT NULL DEFAULT 'NONE',
  `action` varchar(50) NOT NULL DEFAULT 'NONE',
  `parameters` varchar(100) NOT NULL DEFAULT 'NONE',
  `parameter_label` varchar(25) DEFAULT NULL,
  `value` varchar(50) NOT NULL DEFAULT 'NONE',
  PRIMARY KEY (`id`),
  KEY `multiaccountflag` (`multiaccountflag`),
  KEY `parent` (`parent`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cbsg_init_menu`
--

INSERT INTO `cbsg_init_menu` (`id`, `body_en`, `body_sw`, `type`, `child_type`, `parent`, `multiaccountflag`, `menuheader`, `hide`, `user_level`, `constrain`, `cparams`, `action`, `parameters`, `parameter_label`, `value`) VALUES
(6, 'Change PIN', 'Badili namba ya siri', 1, 'I', 103, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'service', 'CHANGEPASS'),
(106, 'Re-enter new member phone number', 'Ingiza tena namba ya simu ya mwanachama', 1, 'I', 33, '-', 0, 0, 1, 'reConfirmEntry', 'mobile', 'NONE', 'NONE', 'NONE', 'NONE'),
(7, 'Badili Lugha', 'Change Language', 1, 'I', 103, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'service', 'CHANGELANG'),
(8, 'Enter new 4-digit pin', 'Ingiza namba mpya ya siri', 1, 'I', 6, '-', 0, 0, 1, 'minMaxLength', '4,4', 'NONE', 'NONE', 'pk1', 'NONE'),
(9, 'Re-enter new 4-digit pin', 'Ingiza tena namba yako ya siri', 1, 'A', 8, '-', 0, 0, 1, 'minMaxLength', '4,4', 'NONE', 'NONE', 'pk2', 'NONE'),
(10, '1.Swahili\r\n2.English', '1.Swahili\r\n2.English', 1, 'A', 7, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'lang', 'NONE'),
(12, 'Add member', 'Ongeza mwanachama', 1, 'I', -1, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'service', 'CREATEMEMBER'),
(110, 'Enter member full name', 'Ingiza jina la mwanachama', 1, 'A', 106, '-', 0, 0, 1, 'minMaxLength', '4,50', 'NONE', 'NONE', 'name', 'NONE'),
(18, 'Member List', 'Orodha ya wanachama', 1, 'A', -1, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'service', 'GROUPLIST'),
(20, 'Set group rules', 'Weka sheria za kikundi', 1, 'I', -1, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'service', 'GROUPDECISIONS'),
(5, 'Group Initiation', 'Anzisha Kikundi', 1, 'I', -1, '-', 0, 1, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONWE'),
(35, 'Enter member number to be dropped', 'Ingiza namba ya mwanachama anayeondolewa', 1, 'I', 24, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE'),
(24, 'Drop member', 'Kuondoa mwanachama', 1, 'I', -1, '-', 0, 1, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'util_name', 'to other bank account'),
(33, 'Enter new member phone number', 'Ingiza namba ya simu ya mwanachama', 1, 'I', 12, '-', 0, 0, 1, 'isMobileDuplicate', 'NONE', 'NONE', 'NONE', 'mobile', 'NONE'),
(57, 'Enter number of meetings in cycle between 20 and 30', 'Ingiza namba ya mkutano wa mgao kati ya 20 na 30', 1, 'I', 55, '-', 0, 0, 1, 'minMaxValue', '20,30', 'NONE', 'NONE', 'totalmeetings', 'NONE'),
(76, 'Enter min pay-in between meetings (multiple of 1000)', 'Ingiza kiasi cha chini cha malipo yanayolipwa katikati ya mikutano (kwa kiwango cha 1,000)', 1, 'I', 57, '-', 0, 0, 1, 'minMaxValue', '1000,3000000', 'NONE', 'NONE', 'minpayin', 'NONE'),
(21, 'Initate Group (min 15 members)', 'Anzisha kikundi (idadi ya chini wanachama 15)', 1, 'I', -1, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'service', 'INITGROUP'),
(54, 'Have all group members been added? 1. Yes. 2. No', 'Je wanachama wote wameunganishwa? Ingiza 1 kuhakiki  2.hapana', 1, 'A', 21, '-', 0, 0, 1, 'minMaxValue', '1,2', 'NONE', 'NONE', 'confirm', 'NONE'),
(55, 'Enter new chairperson member number', 'Ingiza namba ya uanachama ya mwenyekiti', 1, 'I', 20, '-', 0, 0, 1, 'minMaxValue', '1,30', 'NONE', 'NONE', 'chairman', 'NONE'),
(78, 'Enter loan interest rate %', 'Ingiza kiwango cha ziada ya mkopo katika %', 1, 'I', 76, '-', 0, 0, 1, 'minMaxValue', '0,100', 'NONE', 'NONE', 'loancharge', 'NONE'),
(80, 'Enter max loan duration in number of meetings (maximum 6)', 'Ingiza muda wa juu wa marejesho ya mkopo kwa idadi ya mikutano (isiyozidi 6)', 1, 'A', 78, '-', 0, 0, 1, 'minMaxValue', '1,6', 'GROUPDECISIONS', 'NONE', 'loanduration', 'NONE'),
(103, 'Settings', 'Kirekebishi', 1, 'M', -1, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE'),
(91, 'Re-enter member number to be dropped', 'Ingiza tena namba ya mwanachama anayeondolewa', 1, 'A', 35, '-', 0, 0, 1, 'NONE', 'NONE', 'DROPMEMBER', 'NONE', 'NONE', 'NONE');
