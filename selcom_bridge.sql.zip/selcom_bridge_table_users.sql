
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `temppass` varchar(255) DEFAULT NULL,
  `past_hash` varchar(255) DEFAULT '''''',
  `fullname` varchar(255) NOT NULL,
  `joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `currentlogin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastlogin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `firsttime` varchar(10) NOT NULL,
  `expiry_interval` int(11) DEFAULT NULL,
  `expiry_date` timestamp NULL DEFAULT NULL,
  `token` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `temppass`, `past_hash`, `fullname`, `joined`, `currentlogin`, `lastlogin`, `firsttime`, `expiry_interval`, `expiry_date`, `token`) VALUES
(6, '', 'salma@selcom.net', '$2y$10$fo1LFn3uuP/dRzh5vI2W/e90CR81KGQstme1gKsxP0CpTEWI5M2fG', '', '$2y$10$yYizfnqAcxiiAmaoQLAzve7B7w56i7LsjEB9012HrAKw1Ig1ADoW.,\'\'', 'Salma Lalji', '2018-02-13 07:53:56', '2018-04-10 06:54:17', '2018-03-16 10:53:19', 'false', 30, '2018-03-15 07:53:56', '5acc5f99637cc'),
(11, '', 'salma@wisecrack.ca', '$2y$10$O6AOilTAJdI6ZeHhoLfxH.O2JERSlcpB79zj2cQzKVatRvNtEq.K2', '', '$2y$10$eJPV68ZWDQXUBUvo3MONyeQ82x1KvW8uGAVGQeOU/ZrnxU2gL4ePO,$2y$10$gMAE1PMNlEC1R9N0QEbereAE5lz2b4ciyXbggrdPOClgkDsZgN2..', 'Salma Lalji', '2018-02-28 10:02:55', '2018-04-10 07:18:44', '2018-04-10 07:10:48', 'false', 30, '2018-05-10 07:18:22', '5acc6554560f4'),
(12, 'salma', 'salma@wisecrack.ca', '$2y$10$5WDScN3MG11Kbba.VvIvGuKSCXwmt6vQOWaU2UolD40ebRfKqk9IK', '', NULL, 'Salma Wise Lalji', '2018-04-10 13:12:16', '2018-04-16 13:15:30', '2018-04-16 09:34:13', 'false', NULL, NULL, '5ad4a1f255348');
