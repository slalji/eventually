
-- --------------------------------------------------------

--
-- Table structure for table `cbs_request`
--

DROP TABLE IF EXISTS `cbs_request`;
CREATE TABLE IF NOT EXISTS `cbs_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service` varchar(35) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `endpoint` varchar(35) NOT NULL,
  `url_pattern` varchar(100) DEFAULT NULL,
  `http_method` varchar(10) NOT NULL,
  `req_template` text,
  `update_settings_column` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service` (`service`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
