
-- --------------------------------------------------------

--
-- Table structure for table `loan_request`
--

DROP TABLE IF EXISTS `loan_request`;
CREATE TABLE IF NOT EXISTS `loan_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fulltimestamp` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `serial` varchar(15) NOT NULL,
  `msisdn` varchar(12) NOT NULL,
  `groupid` int(11) NOT NULL,
  `amount` double NOT NULL,
  `duration` int(3) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `memberno` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `serial` (`serial`),
  KEY `groupid` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
