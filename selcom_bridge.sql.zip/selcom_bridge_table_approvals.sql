
-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

DROP TABLE IF EXISTS `approvals`;
CREATE TABLE IF NOT EXISTS `approvals` (
  `id` int(11) NOT NULL,
  `fulltimestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `request_id` datetime NOT NULL,
  `initiator` varchar(12) NOT NULL,
  `msisdn` varchar(12) NOT NULL,
  `authcode` varchar(8) NOT NULL,
  `authdate` datetime DEFAULT NULL,
  `authstatus` varchar(15) DEFAULT 'PENDING'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
