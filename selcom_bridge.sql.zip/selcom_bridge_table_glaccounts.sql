
-- --------------------------------------------------------

--
-- Table structure for table `glaccounts`
--

DROP TABLE IF EXISTS `glaccounts`;
CREATE TABLE IF NOT EXISTS `glaccounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(15) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `balance` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `glaccounts`
--

INSERT INTO `glaccounts` (`id`, `account`, `description`, `balance`) VALUES
(1, 'GLINCOME01', 'Shareout Income', 1824055);
