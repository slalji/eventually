
-- --------------------------------------------------------

--
-- Table structure for table `cbsg_start_menu`
--

DROP TABLE IF EXISTS `cbsg_start_menu`;
CREATE TABLE IF NOT EXISTS `cbsg_start_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `body_en` varchar(500) NOT NULL,
  `body_sw` varchar(200) NOT NULL,
  `type` int(2) DEFAULT '1',
  `child_type` varchar(1) NOT NULL DEFAULT 'M',
  `parent` int(10) NOT NULL DEFAULT '0',
  `multiaccountflag` varchar(1) NOT NULL DEFAULT '-',
  `menuheader` int(11) NOT NULL DEFAULT '0',
  `hide` int(1) NOT NULL DEFAULT '0',
  `user_level` int(2) NOT NULL,
  `constrain` varchar(50) NOT NULL DEFAULT 'NONE',
  `cparams` varchar(50) NOT NULL DEFAULT 'NONE',
  `action` varchar(50) NOT NULL DEFAULT 'NONE',
  `parameters` varchar(100) NOT NULL DEFAULT 'NONE',
  `parameter_label` varchar(25) DEFAULT NULL,
  `value` varchar(50) NOT NULL DEFAULT 'NONE',
  PRIMARY KEY (`id`),
  KEY `multiaccountflag` (`multiaccountflag`),
  KEY `parent` (`parent`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cbsg_start_menu`
--

INSERT INTO `cbsg_start_menu` (`id`, `body_en`, `body_sw`, `type`, `child_type`, `parent`, `multiaccountflag`, `menuheader`, `hide`, `user_level`, `constrain`, `cparams`, `action`, `parameters`, `parameter_label`, `value`) VALUES
(1, 'Choose language\r\n1.Swahili\r\n2.Engilish', 'Chagua Lugha\r\n1.Swahili\r\n2.Engilish', 1, 'I', 4, '-', 0, 0, 1, 'updateLangauage', 'NONE', 'NONE', 'NONE', 'service', 'CREATEGROUP'),
(2, 'Please enter your full name.', 'Tafadhali ingiza jina lako.', 1, 'I', 1, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'cname', 'NONE'),
(3, 'Please enter savings group name (max 35 characters).', 'Tafadhali ingiza jina la kikundi (Isizidi tarakimu 35).', 1, 'A', 2, '-', 0, 0, 1, 'minMaxLength', '3,35', 'NONE', 'NONE', 'name', 'NONE'),
(4, 'test', 'test', 1, 'I', -1, '-', 0, 0, 1, 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE');
