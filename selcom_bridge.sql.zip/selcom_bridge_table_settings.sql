
-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `sgroup` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'GENERAL',
  `value` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `tstatus` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'NEW',
  `creator` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'DEFAULT',
  `modifier` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'DEFAULT',
  `authorizer` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'DEFAULT',
  `astatus` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'PENDING',
  `rtimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting`, `sgroup`, `value`, `tstatus`, `creator`, `modifier`, `authorizer`, `astatus`, `rtimestamp`, `uid`) VALUES
(1, 'ADMINFEE_PERCENTAGE', 'GENERAL', '0', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-06-12 01:11:09', 1),
(2, 'TOKEN_EXPIRY_MINS', 'GENERAL', '5', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-06-12 01:11:52', 2),
(3, 'MIN_APPROVAL_REQUIRED', 'GENERAL', '3', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-06-12 01:12:17', 1),
(4, 'MAX_AUTH_SEND_COUNT', 'GENERAL', '5', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-06-12 01:12:46', 4),
(5, 'MIN_MEMBERS_ON_INIT', 'GENERAL', '4', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-06-13 12:26:03', 5),
(6, 'MIN_WITHDRAWAL', 'GENERAL', '1000', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-07-04 23:57:48', 1),
(7, 'MIN_THIRDPARY_PAY', 'GENERAL', '1000', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-07-04 23:58:24', 1),
(8, 'MIN_LOAN', 'GENERAL', '1000', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-07-04 23:59:10', 1),
(9, 'MIN_DEATH_PAY', 'GENERAL', '1000', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-07-04 23:59:24', 1),
(10, 'MIN_SHAREOUT', 'GENERAL', '1000', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-07-04 23:59:39', 1),
(11, 'SHAREOUT_USERFEE', 'GENERAL', '10000', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-10-31 20:37:23', 1),
(12, 'MAX_MEMBERS_LIMIT', 'GENERAL', '30', 'NEW', 'DEFAULT', 'DEFAULT', 'DEFAULT', 'PENDING', '2016-11-21 13:23:18', 1);
